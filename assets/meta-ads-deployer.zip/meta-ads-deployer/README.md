# Meta Ads Deployer

Deploy Facebook & Instagram ad campaigns straight from VS Code — no Ads Manager clicking required.

## Setup (one time)

1. Open this folder in VS Code
2. Make sure you have the **Claude Code extension** installed (search "Claude Code" by Anthropic in the Extensions panel)
3. Open a terminal in VS Code and run:
   ```
   pip install requests python-dotenv
   ```
4. That's it — credentials are already configured.

## How to deploy a campaign

1. Open the Claude Code panel (spark icon, top right)
2. Type:
   ```
   /meta-ads-campaign
   ```
3. Claude will ask you questions about the campaign (objective, budget, targeting, video files, etc.)
4. Review and approve the ad copy it generates
5. Type **DEPLOY** when the checklist looks good
6. Claude uploads your videos and creates everything in Meta — all **PAUSED**
7. Go to Meta Ads Manager to review, then activate when ready

## What you'll need for each campaign

- Your rendered video files (MP4, H.264) somewhere on your computer
- The full file path to each video (e.g. `/Users/you/Videos/ad1.mp4`)
- The landing page URL
- Target location, daily budget, and campaign goal

## After a deploy

A `meta_campaign_log.json` file is saved in this folder with all the campaign IDs.
If anything fails mid-deploy, just run `/meta-ads-campaign` again — already-uploaded
videos are automatically skipped.

## Ads Manager

[Open Meta Ads Manager](https://www.facebook.com/adsmanager/manage/campaigns?act=1382592032805080)
