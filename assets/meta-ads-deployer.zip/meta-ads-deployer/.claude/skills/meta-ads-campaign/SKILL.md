---
name: meta-ads-campaign
description: >
  Deploy a complete Facebook & Instagram ad campaign to Meta Ads Manager with one command.
  Use this skill whenever the user wants to launch, deploy, or create a Meta/Facebook/Instagram
  ad campaign — even if they say "run ads", "set up a campaign", "push ads to Meta", or
  "deploy video ads". Handles the full pipeline: gather campaign details, generate ad copy,
  build UTM tracking URLs, run a pre-deploy checklist, then deploy everything via the Meta
  Graph API. All ads deploy as PAUSED so the user can review before going live. Saves a local
  JSON log file — no database required.
---

# Meta Ads Campaign Deployer

Deploy Facebook & Instagram campaigns from the terminal. No database needed — just your
Meta access token, video files, and this skill.

Everything deploys **PAUSED**. You review in Meta Ads Manager, then activate when ready.

---

## Before You Start

Make sure the project has a `.env` file with:

```
META_ACCESS_TOKEN=your_system_user_token_here
```

You can also pre-set these to skip questions later (optional):
```
META_AD_ACCOUNT_ID=act_123456789
META_PAGE_ID=123456789
```

---

## Phase 1: Gather Campaign Context

Read `.env` (and `.env.local` if it exists) to pre-fill what you can. Then ask the user
for anything that's missing. Ask conversationally — one topic at a time, not a big list.

Collect:

1. **Ad Account ID** — format `act_123456789`. Find it in the Ads Manager URL or Business
   Settings. If `META_AD_ACCOUNT_ID` is in `.env`, confirm it rather than re-asking.

2. **Facebook Page ID** — the Page the ads will run from. If `META_PAGE_ID` is in `.env`,
   confirm it. Otherwise ask. (Tip: found in the Page's About section, or via
   `GET /me/accounts?access_token=...`)

3. **Campaign Objective** — ask what they're trying to achieve. Map their answer to the
   correct Meta API value:
   - Lead generation → `OUTCOME_LEADS`
   - Website traffic → `OUTCOME_TRAFFIC`
   - Brand awareness → `OUTCOME_AWARENESS`
   - Purchases/conversions → `OUTCOME_SALES`

4. **Campaign Name** — suggest a slug-style default: `{client}-{month}-{year}-{objective}`
   e.g. `acme-roofing-april-2026-leads`. Let them override.

5. **Daily Budget** — in dollars (e.g. $50/day). You'll convert to cents for the API.

6. **Geographic Targeting** — ask for country (e.g. US, CA) or specific region. If they
   give a region name (e.g. "Saskatchewan"), remind them to validate the region key via:
   ```
   GET https://graph.facebook.com/v21.0/search?type=adgeolocation&location_types=region&q=Saskatchewan&access_token={token}
   ```
   Always use the `key` from the API response — never guess region keys.

7. **Landing Page URL** — where clicks will go (e.g. `https://client.com/free-quote`).

8. **Video Assets** — for each video ad, collect:
   - Full local file path to the MP4
   - A short name/title for the ad (e.g. "Rate Hikes News Hook")
   - Format: vertical (9:16), square (1:1), or landscape (16:9)
   
   If they have multiple formats of the same concept (e.g. a vertical AND a square version
   of the same ad), group them together as one "multi-format" ad — Meta will serve the
   best format per placement automatically.

Confirm everything with the user before moving on. Show a clean summary.

---

## Phase 2: Generate Ad Copy

For each ad (or ad concept if multi-format), generate:

- **Primary Text** — 2–4 sentences. Hook → problem/value → call to action.
- **Headline** — 5–7 words, benefit-focused, punchy.
- **Description** — 1 sentence supporting the headline.
- **CTA Button** — pick the best fit: `LEARN_MORE`, `GET_QUOTE`, `SIGN_UP`,
  `CONTACT_US`, `APPLY_NOW`, `BOOK_TRAVEL`, `DOWNLOAD`, `SHOP_NOW`.

Present each ad's copy clearly, like:

```
Ad 1: "Rate Hikes News Hook"
  Primary text: Your electricity bill just went up again — and it's not stopping there...
  Headline: Stop Paying More Every Year
  Description: Get a free solar savings report for your home.
  CTA: LEARN_MORE

Approve? (y to approve, or tell me what to change)
```

Do not proceed until all ads are approved. Regenerate on request.

---

## Phase 3: Generate UTM Tracking URLs

For each ad, build a full tracking URL:

```
{landing_page}?utm_source=meta&utm_medium=paid_social&utm_campaign={campaign_slug}&utm_content={content_tag}
```

**Campaign slug format:** `{client-slug}-{month}-{year}-{objective}`
- Lowercase, hyphen-separated
- No tool names, no redundant suffixes
- Example: `acme-roofing-april-2026-leads`

**Content tag format:** `v{version}-{funnel_stage}-{descriptive-slug}`
- Funnel stages: `tof` (top), `mof` (mid), `bof` (bottom)
- Example: `v1-tof-rate-hikes-news`

Show all UTM URLs to the user. Ask them to confirm they look correct before proceeding.

---

## Phase 4: Pre-Deploy Checklist

Show this checklist and ask the user to confirm each item:

```
Pre-Deploy Checklist:
  [ ] All video files exist at their specified local paths
  [ ] Ad copy reviewed and approved for all ads
  [ ] UTM URLs look correct
  [ ] Landing page is live and accessible
  [ ] Ad Account ID: act_XXXXXXX
  [ ] Facebook Page ID: XXXXXXX
  [ ] Campaign objective: OUTCOME_LEADS
  [ ] Daily budget: $XX/day
  [ ] Geographic targeting: [country/region]
  [ ] All ads will deploy as PAUSED — you activate manually in Ads Manager
```

Fill in the actual values. Ask the user to type **DEPLOY** to proceed. Do not deploy
until you receive that word.

---

## Phase 5: Deploy to Meta

Write and execute a Python script that does the following steps in order. Print a progress
line at each step. If any step fails, print the full error, explain what went wrong, save
whatever was completed to the log, and stop cleanly.

### Script setup

```python
import os, json, requests, time
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

ACCESS_TOKEN = os.environ.get('META_ACCESS_TOKEN')
AD_ACCOUNT_ID = '{ad_account_id}'   # from Phase 1
PAGE_ID = '{page_id}'               # from Phase 1
API_VERSION = 'v21.0'
BASE = f'https://graph.facebook.com/{API_VERSION}'

def api_get(path, params=None):
    p = params or {}
    p['access_token'] = ACCESS_TOKEN
    r = requests.get(f'{BASE}/{path}', params=p)
    r.raise_for_status()
    return r.json()

def api_post(path, data=None, files=None):
    d = data or {}
    d['access_token'] = ACCESS_TOKEN
    r = requests.post(f'{BASE}/{path}', data=d, files=files)
    r.raise_for_status()
    return r.json()

log = {
    'campaign_name': '{campaign_name}',
    'deployed_at': time.strftime('%Y-%m-%d %H:%M:%S'),
    'status': 'in_progress',
    'campaign_id': None,
    'adset_id': None,
    'pixel_id': None,
    'ads': []
}
```

### Step 1: Upload videos

For each video file, check if it was already uploaded in a previous run (look for a
`meta_campaign_log.json` in the project root — if a video path already has a `video_id`,
skip the upload and reuse it):

```python
with open(video_path, 'rb') as f:
    result = api_post(f'{AD_ACCOUNT_ID}/advideos',
        data={'name': video_title},
        files={'source': f}
    )
video_id = result['id']
print(f'✓ Uploaded: {video_title} → {video_id}')
```

### Step 2: Create campaign

```python
campaign = api_post(f'{AD_ACCOUNT_ID}/campaigns', data={
    'name': campaign_name,
    'objective': campaign_objective,
    'status': 'PAUSED',
    'special_ad_categories': '[]',
})
campaign_id = campaign['id']
log['campaign_id'] = campaign_id
print(f'✓ Campaign created: {campaign_id}')
```

### Step 3: Auto-discover pixel

```python
pixels = api_get(f'{AD_ACCOUNT_ID}/adspixels', params={'fields': 'id,name'})
pixel_id = pixels['data'][0]['id'] if pixels.get('data') else None
log['pixel_id'] = pixel_id
if pixel_id:
    print(f'✓ Pixel found: {pixel_id}')
else:
    print('⚠ No pixel found — continuing without conversion tracking')
```

### Step 4: Create ad set

Map the campaign objective to the right optimization goal:
- `OUTCOME_LEADS` → `optimization_goal: LEAD_GENERATION`, `billing_event: IMPRESSIONS`
- `OUTCOME_TRAFFIC` → `optimization_goal: LINK_CLICKS`, `billing_event: LINK_CLICKS`
- `OUTCOME_AWARENESS` → `optimization_goal: REACH`, `billing_event: IMPRESSIONS`
- `OUTCOME_SALES` → `optimization_goal: OFFSITE_CONVERSIONS`, `billing_event: IMPRESSIONS`

```python
targeting = {
    'geo_locations': {'countries': [country_code]},
    'targeting_automation': {'advantage_audience': 1}
}
# If targeting a specific region instead of whole country:
# 'geo_locations': {'regions': [{'key': 'region_key_here'}]}

promoted_object = {'page_id': PAGE_ID}
if pixel_id:
    promoted_object['pixel_id'] = pixel_id
    if campaign_objective == 'OUTCOME_LEADS':
        promoted_object['custom_event_type'] = 'LEAD'

adset = api_post(f'{AD_ACCOUNT_ID}/adsets', data={
    'name': f'{campaign_name} - Ad Set',
    'campaign_id': campaign_id,
    'daily_budget': str(int(daily_budget_usd * 100)),  # dollars → cents
    'billing_event': billing_event,
    'optimization_goal': optimization_goal,
    'status': 'PAUSED',
    'targeting': json.dumps(targeting),
    'promoted_object': json.dumps(promoted_object),
})
adset_id = adset['id']
log['adset_id'] = adset_id
print(f'✓ Ad set created: {adset_id}')
```

### Step 5: Create ads (one per approved ad)

For each ad:

```python
# Build video data spec
video_data = {
    'video_id': video_id,
    'message': primary_text,
    'call_to_action': {
        'type': cta_type,
        'value': {'link': utm_url}
    },
    'title': headline,
    'link_description': description,
}

# Create creative
creative = api_post(f'{AD_ACCOUNT_ID}/adcreatives', data={
    'name': f'{ad_title} - Creative',
    'object_story_spec': json.dumps({
        'page_id': PAGE_ID,
        'video_data': video_data
    }),
})
creative_id = creative['id']

# Create ad
ad = api_post(f'{AD_ACCOUNT_ID}/ads', data={
    'name': ad_title,
    'adset_id': adset_id,
    'creative': json.dumps({'creative_id': creative_id}),
    'status': 'PAUSED',
})
ad_id = ad['id']

log['ads'].append({
    'title': ad_title,
    'video_id': video_id,
    'creative_id': creative_id,
    'ad_id': ad_id,
    'utm_url': utm_url,
    'status': 'deployed'
})
print(f'✓ Ad created: {ad_title} → {ad_id}')
```

**Multi-format ads:** If an ad concept has multiple video formats (vertical + square, etc.),
try creating a multi-format creative using `asset_feed_spec`. If that API call fails,
fall back to creating one ad per format.

### Step 6: Save local log

```python
log['status'] = 'complete'
with open('meta_campaign_log.json', 'w') as f:
    json.dump(log, f, indent=2)
print('\n✓ Log saved to meta_campaign_log.json')
```

---

## Phase 6: Post-Deploy Summary

After a successful deploy, show:

```
✅ Campaign deployed successfully — everything is PAUSED.

Campaign ID:  {campaign_id}
Ad Set ID:    {adset_id}
Ads deployed: {N}

Open Ads Manager to review, then activate:
https://www.facebook.com/adsmanager/manage/campaigns?act={account_id_number_only}

All IDs saved to: meta_campaign_log.json
```

Remind the user: nothing is spending money yet. They must manually activate in Ads Manager.

---

## Error Handling & Retries

If the deploy fails partway through:
- Save the log with `status: partial` and everything completed so far
- Print clearly which step failed and why
- Tell the user: "Re-run `/meta-ads-campaign` — already-uploaded videos will be reused
  from the log file, and you can pick up from where we left off."

On re-run, check `meta_campaign_log.json` for:
- `video_id` entries → skip re-upload for those videos
- `campaign_id` → skip campaign creation if already done

Common errors and fixes:
- **Token invalid/expired**: Go back to Meta Developer dashboard, generate a new system
  user token. System user tokens don't expire; personal tokens expire in 60 days.
- **"App not approved"**: In Development Mode this is normal — your system user can still
  access their own ad account. Switch app to Live mode for production.
- **Wrong region key**: Look up the correct key via the geolocation search API before
  retrying.
- **Video upload fails**: Verify the file path is correct, file is H.264 MP4, and under
  4GB. Re-run — the resume logic will skip already-uploaded files.
- **Missing `requests` or `python-dotenv`**: Run `pip install requests python-dotenv`
  in the terminal first.

---

## UTM Reference

| Parameter | Value |
|-----------|-------|
| utm_source | meta |
| utm_medium | paid_social |
| utm_campaign | `{client}-{month}-{year}-{objective}` |
| utm_content | `v{n}-{tof/mof/bof}-{slug}` |

Never include tool names (claude, remotion, etc.) in UTM parameters.
