# Generated Ads — Higgsfield Output URLs

The 6 paid-social ads generated using the workflow in this bundle.
Hosted on Higgsfield's CDN. To get the image files:

1. Click each URL below.
2. Right-click the image → "Save Image As..." → save into `ads/` next to this file.
3. Or open in your Higgsfield account (`show_generations` → find by job ID).

Once images are saved, your designer overlays the HCP logo (top-left)
and the official G2 award badges (where appropriate) in Figma.

---

## 16:9 — Meta News Feed

### Ad 1 — "THE BUSYWORK / RUNS ITSELF" (Real Pro + reporting card variant)

- **URL:** https://d8j0ntlcm91z4.cloudfront.net/user_3CicKYNLKOHaYm6jbxFyp6B1G29/hf_20260507_195609_d16874ba-e5e3-4e12-bfc5-9286be6e20d1.png
- **Job ID:** d16874ba-e5e3-4e12-bfc5-9286be6e20d1
- **Template:** Template A — Real Pro + Two-Tone Rough Headline
- **Caption:** The busywork runs itself — so you can run your crew. 200K+ Pros use Housecall Pro to take admin off their plate. Get started today.

### Ad 2 — Testimonial: "I CAN ACCEPT ALL MAJOR CREDIT CARDS..."

- **URL:** https://d8j0ntlcm91z4.cloudfront.net/user_3CicKYNLKOHaYm6jbxFyp6B1G29/hf_20260507_195617_3b038ba9-90a5-47b2-9a24-0b431c4f9da9.png
- **Job ID:** 3b038ba9-90a5-47b2-9a24-0b431c4f9da9
- **Template:** Template B — Studio Portrait Testimonial
- **Caption:** "I can accept all major credit cards... It's made life so much easier." — Abel L., 2nd Generation Carpet Cleaning. Get started today.

### Ad 3 — "TRUSTED BY 200K+ HOME SERVICE PROS"

- **URL:** https://d8j0ntlcm91z4.cloudfront.net/user_3CicKYNLKOHaYm6jbxFyp6B1G29/hf_20260507_195626_176ac824-96b2-40d9-902c-5dcde3b5f2e3.png
- **Job ID:** 176ac824-96b2-40d9-902c-5dcde3b5f2e3
- **Template:** Trust template (designer adds official G2 badges in Figma)
- **Caption:** Trusted by 200,000+ home service Pros. One platform that runs everything from quote to paid. Start your free trial today.

---

## 9:16 — Stories / Reels

### Ad 4 — "THE BUSYWORK / RUNS ITSELF" (Lifestyle full-bleed)

- **URL:** https://d8j0ntlcm91z4.cloudfront.net/user_3CicKYNLKOHaYm6jbxFyp6B1G29/hf_20260507_195633_c2172520-badd-424a-8004-dcd1b24c29cf.png
- **Job ID:** c2172520-badd-424a-8004-dcd1b24c29cf
- **Caption:** The busywork runs itself. So you can run your crew. Get started today.

### Ad 5 — "PRO INVOICES / AT YOUR FINGERTIPS"

- **URL:** https://d8j0ntlcm91z4.cloudfront.net/user_3CicKYNLKOHaYm6jbxFyp6B1G29/hf_20260507_195640_38a0bb92-589c-4ad2-90db-1f566e8ede3e.png
- **Job ID:** 38a0bb92-589c-4ad2-90db-1f566e8ede3e
- **Caption:** Pro invoices. At your fingertips. Send them, track them, get paid faster — all from your phone. Get started today.

### Ad 6 — "ONE PLATFORM / TOTAL CONTROL"

- **URL:** https://d8j0ntlcm91z4.cloudfront.net/user_3CicKYNLKOHaYm6jbxFyp6B1G29/hf_20260507_195644_1273ac08-545a-4194-b4f4-42dc00c91263.png
- **Job ID:** 1273ac08-545a-4194-b4f4-42dc00c91263
- **Caption:** One platform. Total control. Quote, schedule, dispatch, get paid — all from one place. Get started today.

---

**Note for the designer:**
Top-left corner is intentionally blank in all 6 ads — overlay the official HCP
logo (door icon + "Housecall Pro" wordmark, no circle) in Figma. For Ad 3,
also overlay the official G2 award badges in the right-side empty zone.
