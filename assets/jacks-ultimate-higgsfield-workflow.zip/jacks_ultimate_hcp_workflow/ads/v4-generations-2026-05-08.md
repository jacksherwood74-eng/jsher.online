# Generated Ads v4 — Higgsfield Output URLs (2026-05-08)

10 paid-social ads generated using the workflow in this bundle.
Built with the HCP style guide skill, copy skill (testimonial bank
+ pillar messaging), motion-design / cinematic prompting skills,
and visual reference from the 9 top-performing existing statics.

Hosted on Higgsfield's CDN. To get the image files:

1. Click each URL below.
2. Right-click the image → "Save Image As..." → save into `ads/`.
3. Or open in Higgsfield (`show_generations` → find by job ID).

**Designer post-production for every ad below:**
- Overlay the official HCP logo (door icon + "Housecall Pro" wordmark, no
  circle) in the top-left corner — every ad has the top-left intentionally
  blank.
- For any campaign requiring G2 social proof, overlay the official current-
  quarter G2 badges in Figma. None of these ads include AI-rendered badges
  or placeholder badge zones.

---

## 9:16 — Stories / Reels

### Ad 1 — "BUSY WORK / STEALS YOUR TIME"

- **URL:** https://d8j0ntlcm91z4.cloudfront.net/user_3CicKYNLKOHaYm6jbxFyp6B1G29/hf_20260508_192434_b19ef159-79d3-4523-bab5-572dfa68d0f9.png
- **Job ID:** b19ef159-79d3-4523-bab5-572dfa68d0f9
- **Template:** C — Real Pro Lifestyle (Outdoor) + Two-Tone Rough Headline
- **Pillar:** #1 Administrative relief / "busy work" pain
- **Caption:** Busy work steals your time. Housecall Pro takes it back — scheduling, invoicing, dispatching, all from one app. Get started today.

### Ad 2 — "PRO INVOICES / AT YOUR FINGERTIPS"

- **URL:** https://d8j0ntlcm91z4.cloudfront.net/user_3CicKYNLKOHaYm6jbxFyp6B1G29/hf_20260508_192443_9272136a-7eb0-46dc-a0f4-75988036114b.png
- **Job ID:** 9272136a-7eb0-46dc-a0f4-75988036114b
- **Template:** D — Phone-in-Pocket Reveal
- **Pillar:** #2 Payment acceptance / getting paid easily
- **Caption:** Pro invoices. At your fingertips. Send them, track them, get paid faster — all from your phone. Get started today.

### Ad 3 — "DON'T STRESS THE BACK OFFICE / BE THE PRO"

- **URL:** https://d8j0ntlcm91z4.cloudfront.net/user_3CicKYNLKOHaYm6jbxFyp6B1G29/hf_20260508_192449_0aa74e3c-bc89-4d9c-a052-90811e7ffbee.png
- **Job ID:** 0aa74e3c-bc89-4d9c-a052-90811e7ffbee
- **Template:** B — Real Pro Studio Portrait + Two-Tone Rough Headline (3-line)
- **Pillar:** #1 Administrative relief
- **Caption:** Don't stress the back office. Be the Pro. We'll be everything else. Start your free trial today.

### Ad 4 — Testimonial: "TEN HATS OFF / MY HEAD." — Jake C.

- **URL:** https://d8j0ntlcm91z4.cloudfront.net/user_3CicKYNLKOHaYm6jbxFyp6B1G29/hf_20260508_192456_fd408b25-de49-429e-b0d8-ec44f3bc632c.png
- **Job ID:** fd408b25-de49-429e-b0d8-ec44f3bc632c
- **Template:** B — Real Pro Studio Portrait Testimonial
- **Pillar:** #1 Administrative relief (via testimonial bank)
- **Caption:** "Using Housecall Pro definitely felt like it took maybe 10 hats off of my head." — Jake C., Motherflushers Plumbing. Get started today.

### Ad 5 — "ONE TAP. / GET PAID."

- **URL:** https://d8j0ntlcm91z4.cloudfront.net/user_3CicKYNLKOHaYm6jbxFyp6B1G29/hf_20260508_192502_214ef66e-c22b-4c92-9b81-18b90c742d53.png
- **Job ID:** 214ef66e-c22b-4c92-9b81-18b90c742d53
- **Template:** C — Real Pro Lifestyle (Outdoor)
- **Pillar:** #2 Payment acceptance / getting paid easily
- **Caption:** One tap. Get paid. Run cards from anywhere — no extra hardware, no friction. Get started today.

---

## 16:9 — Meta News Feed

### Ad 6 — "THE BUSYWORK / RUNS ITSELF"

- **URL:** https://d8j0ntlcm91z4.cloudfront.net/user_3CicKYNLKOHaYm6jbxFyp6B1G29/hf_20260508_192509_6c971dc6-a731-45de-a909-4c5467038873.png
- **Job ID:** 6c971dc6-a731-45de-a909-4c5467038873
- **Template:** A — Real Pro + Two-Tone Rough Headline (no reporting card per current rules)
- **Pillar:** #1 Administrative relief
- **Caption:** The busywork runs itself — so you can run your crew. 200K+ Pros use Housecall Pro to take admin off their plate. Get started today.

### Ad 7 — Testimonial: "EVERY PART OF MY BUSINESS / RUNS THROUGH HOUSECALL PRO." — Ian C.

- **URL:** https://d8j0ntlcm91z4.cloudfront.net/user_3CicKYNLKOHaYm6jbxFyp6B1G29/hf_20260508_192514_7d170f79-214e-48ce-9ee4-7872516321bb.png
- **Job ID:** 7d170f79-214e-48ce-9ee4-7872516321bb
- **Template:** B — Studio Portrait Testimonial
- **Pillar:** #3 All-in-one / replace multiple tools
- **Caption:** "Every part of my business essentially runs through Housecall Pro." — Ian C., Current Solutions Electric. Start your free trial today.

### Ad 8 — "POWER UP / YOUR BUSINESS"

- **URL:** https://d8j0ntlcm91z4.cloudfront.net/user_3CicKYNLKOHaYm6jbxFyp6B1G29/hf_20260508_192521_bdff1212-74da-49fc-8873-5ac1318687a2.png
- **Job ID:** bdff1212-74da-49fc-8873-5ac1318687a2
- **Template:** E — AI / Tech-Forward (warm light streaks + Screen Blue spark accents)
- **Pillar:** AI / business growth — MoFu demo CTA
- **Caption:** Power up your business. AI that works the way you do — quotes, scheduling, follow-ups, all handled. Book a demo today.

### Ad 9 — "ELECTRICIANS / LOVE OUR SOFTWARE."

- **URL:** https://d8j0ntlcm91z4.cloudfront.net/user_3CicKYNLKOHaYm6jbxFyp6B1G29/hf_20260508_192527_04201796-e185-4feb-9cfb-a93eacbc6fe7.png
- **Job ID:** 04201796-e185-4feb-9cfb-a93eacbc6fe7
- **Template:** A — Real Pro + Two-Tone Rough Headline
- **Pillar:** #6 Trade-specific validation
- **Caption:** Electricians love our software. Why? Online schedules, text updates, auto invoices, instant reviews — grow your electrical business the easy way. Start your free trial today.

### Ad 10 — "FROM QUOTE / TO PAID."

- **URL:** https://d8j0ntlcm91z4.cloudfront.net/user_3CicKYNLKOHaYm6jbxFyp6B1G29/hf_20260508_192712_dd616761-eacf-4555-a2a0-def44805275b.png
- **Job ID:** dd616761-eacf-4555-a2a0-def44805275b
- **Template:** C — Real Pro Lifestyle (Outdoor)
- **Pillar:** #3 All-in-one + #2 Payment ease
- **Caption:** From quote to paid — all in one app. Quote, schedule, dispatch, invoice, collect. Start your free trial today.

---

**Generation summary**
- Model: `marketing_studio_image` (Higgsfield Marketing Studio Image, 1k resolution)
- Total credits used: ~300 (10 × ~30 each)
- Style guide compliance: Royal Navy `#003A6D` + Saffron Orange `#FF9B24`, Headline Gothic ATF Rough split white→orange, real Pros (no stock), top-left blank, no AI G2 badges, no reporting cards.
- Generated by Jackson Sherwood via Cowork + Higgsfield workflow.
