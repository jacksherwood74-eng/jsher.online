---
name: jacks-ultimate-style-guide-skill
description: Apply Housecall Pro's preliminary 2026 visual brand standards
  (mini style guide, dated 04.14.26) when generating any HCP marketing
  asset — paid social ads, web pages, event posters, email heroes, podcast
  artwork, banners, decks. Use whenever the user asks for HCP creative,
  HCP ads, HCP brand-aligned design, or anything where the visual must
  read as "from Housecall Pro." Includes new color palette (Saffron Orange
  replaces Golden Yellow; Royal Navy replaces Dark Blue), new typography
  (Headline Gothic ATF in Round + Rough levels replaces Open Sans for
  headlines; Plus Jakarta Sans stays for body), the two-tone rough
  headline pattern (white + orange split), photography spec (real Pros,
  not stock), and reusable layout templates for static paid ads, email
  heroes, growth-site heroes, and event creative.
---

# Housecall Pro Mini Style Guide — Skill

**Source:** HCP internal mini style guide, dated 04.14.26, marked PRELIMINARY.
This skill encodes the visual rules so that AI-generated creative reads as
authentically Housecall Pro on first glance.

When generating an HCP visual asset, apply every rule in this skill.

---

## Brand pillars (the "why" behind the system)

The visual evolution reflects three brand pillars:

- **Trust** — built through consistency and recognizable craft.
- **Confidence** — the brand sounds and looks sure of itself.
- **Connection to the trades** — orange signals work-being-done and safety;
  rough typography signals craft and the human hand.

When choosing between two visual options, pick the one that signals "real
work, real Pros, real outcomes" — not the polished-SaaS option.

---

## Color palette (canonical hex codes)

Use these hex codes verbatim. No substitutes. No approximations.

| Color | Hex | Use |
|---|---|---|
| Custom Black | `#13181A` | Backgrounds, type on light backgrounds |
| Royal Navy | `#003A6D` | Primary background for paid ads, hero blocks |
| Screen Blue | `#0065C1` | Printable replacement for old Cyber Blue. Use for in-product UI screens, secondary accents, and links. **Do not use the old `#0055FF`** — guide explicitly notes "current blue is unprintable." |
| Pale Slate | `#CCD5DB` | Light dividers, secondary surfaces |
| Platinum | `#F0F4F7` | Light backgrounds, cards on dark |
| Saffron Orange | `#FF9B24` | **Accent only.** CTA buttons, highlighted headline words, growth-metric callouts, key emphasis. Replaces old Golden Yellow `#FFB706`. |

### What changed and why

- **Yellow → Orange.** The guide explicitly retires Golden Yellow in favor of
  Saffron Orange. *"Orange is a color associated with work being done. It
  also signals safety, which builds on the pillars of trust and confidence."*
- **Cyber Blue → Screen Blue.** Old Cyber Blue (`#0055FF`) was unprintable.
  New Screen Blue (`#0065C1`) holds in print + screen and reads less neon.
- **Dark Blue → Royal Navy.** Old Dark Blue `#0A2443` shifts to Royal Navy
  `#003A6D` — slightly less black, more pure-blue.

### Color combinations that work

Tested combinations from the guide:

- Royal Navy (`#003A6D`) background + white text + Saffron Orange (`#FF9B24`) accent → primary paid-ad system
- Custom Black (`#13181A`) background + white text + Saffron Orange (`#FF9B24`) accent → premium / high-impact
- Royal Navy + Pale Slate (`#CCD5DB`) for monochromatic-blue compositions

---

## Typography

### Headline typeface — Headline Gothic ATF (NEW)

Three levels, all used for H1 / display only:

1. **Headline Gothic ATF — Round.** Cleaner, geometric-rounded version. Use for
   formal headlines and longer phrases where readability matters.
2. **Headline Gothic ATF — Rough No.1.** Light distressed/eroded edges. Mid-grit.
   Use for most paid-ad headlines.
3. **Headline Gothic ATF — Rough No.2.** Heavier distressed/eroded edges. High-grit.
   Use for the most expressive headline moments — large posters, hero ads.

> *"Utilize 3 levels of degradation, cater to use-case."* — guide

### Body typeface — Plus Jakarta Sans

All weights. Use for body copy, subheads, captions, UI elements, app badges.

### Old typography that's retired

- **Open Sans** is being sunset. Do not use Open Sans for any new HCP creative.
- **Kallisto** (old tertiary display font) is no longer in the system.

### Why this typography matters

> *"No competitor in the trades uses this typeface."* — guide

Headline Gothic ATF + Plus Jakarta Sans is the typographic differentiator from
ServiceTitan, Jobber, FieldPulse, etc. The "rough" levels signal craft — literal
rough edges that match the audience (real tradespeople, not SaaS buyers).

---

## The two-tone rough-headline pattern (signature visual move)

This is the most distinctive HCP visual element. Apply it to nearly every paid ad.

### The rule

A multi-word display headline is split across two lines (or more), with one part
in **pure white** and the other part in **Saffron Orange** (`#FF9B24`), all in
Headline Gothic ATF Rough (No.1 or No.2 depending on grit level desired).

### Examples from the guide (verbatim)

- **THE BUSYWORK / RUNS ITSELF** — "THE BUSYWORK" in white, "RUNS ITSELF" in orange
- **PRO INVOICES / AT YOUR FINGERTIPS** — "PRO INVOICES" in white, "AT YOUR FINGERTIPS" in orange
- **ONE PLATFORM / TOTAL CONTROL** — "ONE PLATFORM" in white, "TOTAL CONTROL" in orange
- **BUSY WORK / STEALS YOUR TIME** — "BUSY WORK" in white, "STEALS YOUR TIME" in orange
- **DON'T STRESS THE BACK OFFICE / BE THE PRO** — "DON'T STRESS THE BACK OFFICE" in white, "BE THE PRO" in orange (with kicker "WE'LL BE EVERYTHING ELSE" below in smaller white)
- **POWER UP YOUR BUSINESS / AI THAT WORKS THE WAY YOU DO** — split white/orange in event hero

### How to choose what's white vs. orange

The orange phrase carries the **payoff** — the benefit, outcome, or punchline.
The white phrase carries the **setup** — the subject, premise, or context.

Setup → payoff. White → orange.

### When to use this pattern

- Static paid ads
- Email heroes
- Growth site heroes
- Event large-format posters

### When NOT to use this pattern

- Body copy
- Long-form text
- Buttons and CTAs (those use a separate spec)
- Product UI

---

## Photography (real Pros, never stock)

The photography spec is unchanged from the previous brand: real Pros, real
workwear, real environments. The new guide reinforces this with examples.

### Specifications

- **Subject** — real working contractor (electrician, HVAC tech, plumber,
  carpet cleaner, painter, etc.). Not a model. Real workwear (company polo,
  jacket, navy uniform, baseball cap, tool belt). Authentic posture.
- **Lighting** — natural daylight or warm interior. Slight blue rim lighting
  in studio shots. No over-polished beauty lighting.
- **Setting** — real working environment: van interior, customer driveway,
  rooftop HVAC unit, electrical panel, residential yard, jobsite. Or a darker
  studio backdrop for portrait/testimonial shots.
- **Mood** — confident, slightly smiling, mid-task or just-finished.
- **Don't** — stock-photo polish, posed studio glam, men-in-suits energy,
  generic professional headshots.

### Photography styles by use case

| Use case | Photography style |
|---|---|
| Paid social hero | Real Pro mid-task, often in warm/dark interior with motion-blur lighting accents around them |
| Testimonial card | Real Pro studio portrait, dark navy backdrop, slight blue rim light, looking at camera |
| Email hero | Real Pro outdoor or in-environment, with phone mockup overlay |
| Event poster | Same as paid social, sized large |
| Growth site hero | Real Pro in workshop / van / on jobsite |

---

## Layout templates (paid-ad system)

The guide shows three canonical paid-ad templates. Use these as scaffolds.

### Template A — "Real Pro + Rough Headline + Reporting Card"

The dominant paid-ad pattern. Page 6 of guide shows three variants.

**Composition:**
- Background: dark photographic environment (warm interior with motion-blur light streaks)
- Real Pro positioned center-top, smiling, mid-task or just-finished
- HCP wordmark logo top-left (white, no decorative elements)
- TWO-TONE ROUGH HEADLINE in upper-mid frame: white setup + orange payoff
- Reporting card (small floating card) lower-mid frame: shows growth metric with up-arrow ("↑15%") in Saffron Orange, plus a small bar chart in Screen Blue
- App Store + Google Play badges bottom (black rounded rectangles, white text + colored play/Apple icon)

**Examples from guide:**
- "THE BUSYWORK / RUNS ITSELF" + electrician in van, "Reporting ↑15%" card
- "PRO INVOICES / AT YOUR FINGERTIPS" + Pro in van, same card pattern
- "ONE PLATFORM / TOTAL CONTROL" + Pro in vehicle, same card pattern

### Template B — "Real Pro Studio Portrait + Two-Tone Rough Headline"

Used in paid social as a more portrait-oriented variant.

**Composition:**
- Background: dark navy or dark studio backdrop, slightly warm
- Real Pro positioned to one side (left or right), studio-lit portrait, slight blue rim light, looking at camera with slight smile
- HCP wordmark top-left (white)
- TWO-TONE ROUGH HEADLINE on opposite side from Pro: white setup + orange payoff
- Optional reporting card overlay
- App store badges bottom

### Template C — "Real Pro Lifestyle (Outdoor) + Rough Headline"

Used in 9:16 stories/reels and event posters.

**Composition:**
- Background: full-bleed real Pro in outdoor working environment (front of truck, residential driveway, jobsite). Photo fills the frame.
- Slight darkening overlay for headline legibility
- TWO-TONE ROUGH HEADLINE superimposed across center-bottom or bottom third
- HCP wordmark top-left
- Optional CTA pill button in Saffron Orange near bottom
- App store badges where applicable

### Template D — "Phone-in-Pocket Reveal" (existing, still in use)

Hand pulling phone from back pocket, app screen visible, stencil-headline overlay.
This continues from the existing brand and is shown in growth site context.

### Template E — "AI / Tech-Forward" (event use, page 14)

For HCP AI / technology-forward content (Power Up, etc.):
- Real Pro in environment + warm light streaks + blue motion-blur accents
- Same two-tone rough headline pattern
- Lightning-bolt/spark visual elements appropriate to "AI" context

---

## Logos and wordmark

### Primary placement

- **Top-left corner** of the asset, in white. Wordmark + door icon.
- HCP wordmark "Housecall Pro" sans-serif, paired with the door icon (bracket-shaped).

### What NOT to do

- Do not enclose the door icon in a circle (the AI-hallucinated bug from prior runs).
- Do not stretch, recolor, rotate, or distort the logo.
- Do not place the logo on Saffron Orange or Royal Navy gradient transitions where it loses contrast.

### For AI-generated creative specifically

Until logo rendering is reliable in image-gen models, **leave the top-left
corner blank** in the prompt. Designer overlays the real HCP logo in Figma
post-generation. This is the best-practice fix that emerged from prior runs.

---

## CTA buttons

### Spec

- **Shape:** Rounded pill (high border-radius, fully rounded ends)
- **Fill color:** Saffron Orange `#FF9B24`
- **Text color:** Custom Black `#13181A` or Royal Navy `#003A6D` — bold weight
- **Typography:** Plus Jakarta Sans Bold

### Approved CTA copy (matched to funnel stage)

| Stage | CTA |
|---|---|
| ToFu / Acquisition | "Start your free trial today" / "Start free trial" / "Book a demo today" |
| MoFu / Consideration | "Book a demo" / "See how it works" |
| BoFu / Retargeting | "Get started" / "Learn more" |

### What NOT to use

- "Click here" — generic
- "Find out more" — weak
- "Sign up now" — too pushy
- ALL CAPS in CTA buttons (use Title Case)

---

## App Store badges

When applicable (ads with download intent):

- Apple App Store badge (black rounded rectangle, "Download on the App Store")
- Google Play badge (black rounded rectangle, "GET IT ON Google Play")
- Placed bottom of frame, side-by-side
- Standard official badges from Apple/Google — never recolored

---

## G2 award badges (official third-party assets — NEVER alter)

The G2 Crowd award badges (Easiest Admin, Easiest Setup, Easiest To Use, Users
Most Likely To Recommend, Best Results, Highest User Adoption, Leader, Best
Est. ROI, Fastest Implementation, Easiest To Do Business With, etc.) are
**official third-party brand assets owned by G2**. They cannot be modified,
recolored, or recreated — the badge shape, the G2 logo (red shield), the banner
colors, and the typography are part of G2's brand system, not HCP's.

### Rule for AI-generated creative — **omit G2 badges entirely**

**Do not include G2 badges in any AI-generated creative.** This includes
"designated empty zones" for them, vertical columns on the right edge, or
any placeholder shapes that suggest where badges will go. Two reasons:

1. AI image-gen produces approximations of G2 badges that look close to
   the real marks but are technically not official, are legally unusable
   in production, and clutter the creative for the designer to clean up.
2. Even "leave space for badges" prompts tend to make the model invent
   shield-shaped objects in the empty zone, defeating the purpose.

The cleaner pattern: **generate the ad without badges at all.** Designer
adds the official G2 badges in Figma post-generation if the campaign uses
them, sized and positioned per HCP brand standards.

If you're tempted to mention badges in a prompt, don't. Treat them like
the HCP logo — entirely a post-production layer.

### Standard G2 badge layouts (for the designer to populate)

- **Vertical column of 6 badges** (right edge of 1:1 ads) — used in Trust
  template ads ("Trusted by 200K+ home service Pros")
- **Horizontal row of 3–6 badges** (bottom of frame) — used in feature/landing
  page heroes
- **Single badge cluster of 3 badges** with a "Leader / Best ROI / Fastest
  Implementation" pattern — used in vertical-specific ads

### When G2 badges are NOT used

- Testimonial cards (where the customer photo + quote IS the social proof)
- Stencil-headline-only paid ads (where the typography IS the brand statement)
- Event posters and large-format event creative

### What the designer adds in production

The designer pulls the current quarter's official G2 badge files (PNG/SVG)
from G2's brand portal or from HCP's brand-asset library, scales them
proportionally to the empty space the AI left, and drops them in. Five
minutes per ad.

---

## Reporting / metric callout cards

The reporting "↑15%" card appears in some HCP brand-deck examples but is
**not a required element** for paid ads. Use it sparingly and only when the
metric is the actual point of the ad. For most retargeting and acquisition
ads, the rough two-tone headline is doing the work — adding a reporting
card on top is visual noise that competes with the headline for attention.

**Default rule for AI-generated paid ads: do not include a reporting card.**
Designer can add a real metric overlay in Figma post-generation if the
campaign brief calls for one. Every prompt should explicitly say "no
reporting card, no growth-percentage callout" unless the ad's whole purpose
is to communicate a number.

---

## Tone-of-typography mapping

Match grit-level of typography to message tone:

| Message tone | Typography |
|---|---|
| Direct, confident outcome | Headline Gothic ATF Round (cleanest) |
| Pain-call-out, real-talk | Headline Gothic ATF Rough No.1 (mid-grit) |
| Punchline, hero moment, emotional payoff | Headline Gothic ATF Rough No.2 (heaviest grit) |
| Body copy, anywhere there's running text | Plus Jakarta Sans |

---

## Aesthetic principles (gut-check before shipping)

1. **Real Pros over stock photos** — every time. If the photo could be in a
   Salesforce ad, it's wrong.
2. **Rough beats polished** — the typography signals craft. Smooth sans-serifs
   make HCP look like every other SaaS brand.
3. **Orange is the punchline** — never the setup. Always the payoff word.
4. **Royal Navy is the canvas** — most ads have it. Custom Black is the
   premium-mode alternative.
5. **One outcome per ad** — don't stack three benefits. Pick the strongest one
   and let the typography carry it.
6. **Real workwear, real environments** — visible logos on company polos, real
   tools, real vans. Authentic > aspirational.

---

## What competitors do that we explicitly don't

- **ServiceTitan** uses generic SaaS lighting + abstract metrics + corporate stock photos. We use real Pros + real environments + concrete outcomes.
- **Jobber** uses heavy testimonial UGC with handheld camera energy. We use polished testimonial portraits in studio + lifestyle photography in real environments.
- **FieldPulse / Service Fusion** lean blue-on-blue with phone screenshots floating in space. We anchor the phone in a Pro's hand or pocket — the device is contextual, not abstract.

The two-tone rough headline + Saffron Orange + Royal Navy combination is the
visual differentiator nobody else in the FSM category is running.

---

## Application: prompts for AI image gen

When writing prompts for Higgsfield (Marketing Studio Image / Seedance 2.0) or
similar models, encode this skill via:

### Required prompt elements

1. **Background spec** — name Royal Navy `#003A6D` or Custom Black `#13181A` explicitly, plus any photographic context (warm interior, motion-blur lighting, etc.).
2. **Pro photography spec** — describe the contractor (trade, age range, workwear, posture, mood). Specify "real Pro, NOT stock photo, photojournalistic style."
3. **Two-tone rough headline** — write out the exact split: white setup + Saffron Orange `#FF9B24` payoff. Explicitly call out "Headline Gothic ATF Rough No.1 or No.2 — distressed eroded edges, sans-serif geometric."
4. **Reporting card** (when applicable) — describe the metric callout: "small white floating card with 'Reporting' header, '↑15%' in Saffron Orange large type, small Screen Blue bar chart."
5. **CTA pill button** — Saffron Orange pill with bold dark navy text reading [approved CTA].
6. **App store badges** — bottom of frame.
7. **Logo guard** — "TOP-LEFT corner: LEAVE COMPLETELY BLANK — designer overlays HCP logo in Figma."

### Example prompt fragment

> Static paid ad for Housecall Pro, 1:1 (1080x1080). Background: Royal Navy
> (`#003A6D`) with subtle warm interior environment, motion-blur light streaks
> in Screen Blue (`#0065C1`) wrapping around the subject. CENTER: photorealistic
> real male electrician in his 30s, wearing a navy company work polo with embroidered
> logo patch, slight smile, looking at camera, mid-task in his service van interior,
> warm key light from above. UPPER-LEFT 50%: massive distressed-stencil rough
> sans-serif headline (Headline Gothic ATF Rough No.2 style — heavy eroded textured
> edges, all caps) — 'THE BUSYWORK' on one line in pure white, 'RUNS ITSELF' on the
> line below in Saffron Orange (`#FF9B24`), same heavy rough treatment. LOWER-LEFT:
> a small white floating card with 'Reporting' header in dark text and a large
> '↑15%' in Saffron Orange next to a small bar chart in Screen Blue. BOTTOM:
> two side-by-side black rounded-rectangle app store badges (App Store + Google
> Play). TOP-LEFT corner: LEAVE COMPLETELY BLANK — designer overlays HCP logo.
> Style: HCP signature rough-meets-premium aesthetic.

---

## Quick reference card

If you only remember five things:

1. **Royal Navy `#003A6D`** background, **Saffron Orange `#FF9B24`** accent.
2. **Headline Gothic ATF Rough** for headlines (split white + orange).
3. **Real Pros**, real workwear, real environments — never stock.
4. **Top-left blank** in AI-generated assets — designer adds logo in Figma.
5. **Rough = craft = HCP's differentiator** in a SaaS category that's all polished.
