# Jack's Ultimate HCP Creative Workflow

A complete bundle for generating Housecall Pro paid social ads using
Cowork + Higgsfield, end-to-end. Anyone can drop this into a fresh Cowork
instance and run the workflow.

---

## What's in this bundle

```
jacks_ultimate_hcp_workflow/
├── README.md                                       ← read this first
├── ads/
│   └── links.md                                    (URLs for the 6 v3 ads + per-ad captions)
├── skills/
│   ├── jacks-ultimate-style-guide-skill.md         (HCP visual brand standards)
│   ├── jacks-ultimate-copy-skill.md                (HCP voice + testimonial bank)
│   ├── jacks-ultimate-cinematic-skill.md           (Higgsfield prompting — cinematic)
│   ├── jacks-ultimate-3d-cgi-skill.md
│   ├── jacks-ultimate-cartoon-skill.md
│   ├── jacks-ultimate-comic-to-video-skill.md
│   ├── jacks-ultimate-fight-scenes-skill.md
│   ├── jacks-ultimate-motion-design-ad-skill.md    (most relevant for SaaS/fintech)
│   ├── jacks-ultimate-ecommerce-ad-skill.md
│   ├── jacks-ultimate-anime-action-skill.md
│   ├── jacks-ultimate-product-360-skill.md
│   ├── jacks-ultimate-music-video-skill.md
│   ├── jacks-ultimate-social-hook-skill.md
│   ├── jacks-ultimate-brand-story-skill.md
│   ├── jacks-ultimate-fashion-lookbook-skill.md
│   ├── jacks-ultimate-food-beverage-skill.md
│   └── jacks-ultimate-real-estate-skill.md
└── reference/
    └── hcp-mini-style-guide-04.14.26.pdf           (source style guide)
```

17 skills total: 2 HCP-specific (style guide + copy) + 15 Higgsfield prompting skills.

---

## Setup (5 minutes)

### 1. Cowork instance prerequisites

You'll need:
- A Cowork-enabled Claude desktop app
- Higgsfield connector installed and authenticated
- Motion connector (optional, for competitive analysis) authenticated to your team's workspace

### 2. Install the skills

Drop all `.md` files from `skills/` into your Cowork skills folder
(`/sessions/<id>/mnt/.claude/skills/` on your local Cowork instance).

Once present, the skills auto-load when their descriptions match your
prompt. The HCP style guide and copy skills are the two most important
for HCP-branded creative.

### 3. Reference the PDF (optional)

The `reference/` folder contains the source style guide PDF (04.14.26).
The `style-guide` skill encodes everything in it, so you don't need to
upload the PDF separately — but keep it handy for spot-checks.

---

## How to run the workflow

### Quick version

In a fresh Cowork chat, paste:

> "Generate 3 × 16:9 and 3 × 9:16 paid retargeting ads for Housecall Pro,
> using the new HCP brand style guide and the proven testimonial copy
> from the copy skill. No reporting cards, no AI-rendered G2 badges —
> leave designated space for the designer."

Cowork picks up the skills automatically. Higgsfield generates the ads.
URLs come back in chat. Right-click → save.

### Full version

1. **Frame your ask.** Surface, audience, angle. Example: "Meta retargeting
   ads for HCP fintech (Instapay), 16:9 + 9:16, conversion-focused."

2. **Pull competitive context** (optional, if Motion is connected). Ask
   Cowork to pull recent active ads from competitors (Jobber, ServiceTitan,
   FieldPulse, Service Fusion). The diff critic surfaces whitespace.

3. **Pull copy from the copy skill.** The skill has a testimonial bank
   (Abel L., Joe M., etc.) and proven hook patterns ("BUSY WORK." pause,
   "Plumbers love our software. Why?", etc.).

4. **Build prompts using the style guide skill.** The skill encodes the
   color palette, typography, two-tone headline pattern, layout templates,
   and logo/badge handling rules.

5. **Generate via Higgsfield.** Marketing Studio Image for statics.
   Seedance 2.0 for motion ads (per the motion-design-ad skill's
   recommendation).

6. **Open URLs, save images.** Designer adds the HCP logo (top-left) and
   G2 badges (where applicable) in Figma post-generation.

---

## Critical rules baked into the skills

These are the hard-learned lessons. Don't break them.

- **Top-left blank.** Designer overlays HCP logo in Figma. AI gen cannot
  reliably render the door+wordmark logo.
- **No AI-rendered G2 badges.** They're official third-party assets.
  Designer adds the real ones in Figma. Don't even leave "designated
  empty zones" for badges — the model invents shield shapes.
- **No reporting `↑15%` cards** unless the metric is the actual point of
  the ad. They clutter the headline.
- **Two-tone rough headlines.** White setup + Saffron Orange payoff.
  Always use Headline Gothic ATF Rough (No.1 or No.2 grit).
- **Real Pros, never stock.** Real workwear, real environments.
- **Royal Navy `#003A6D`** background, **Saffron Orange `#FF9B24`**
  accent. Not the old Dark Blue / Golden Yellow.

---

## Credits and cost ballpark

Higgsfield Marketing Studio Image at 1k resolution: ~30 credits per static.
Seedance 2.0 video at 720p, 6 seconds: ~80–150 credits per clip.

A typical batch (6 statics + 0 video) runs ~180 credits.
A batch with 6 statics + 2 videos runs ~340–480 credits.
Plus accounts have ~600+ credits at start of month.

---

## Two things to do before scaling beyond pilot

1. **Co-build the visual critic skill with Brand.** The style-guide skill
   encodes the rules; the visual critic skill (referenced in the workflow
   docs) scores generated outputs against those rules. The two pair up as
   a generator → critic loop. Brand should own the rubric.

2. **Set up the Motion workspace properly** (one-time setup with the
   Motion CSM). Once the workspace is provisioned and the connector is
   pointed at it, the diff critic and competitive analysis can run live
   in every session instead of being block on async report processing.

---

## Acknowledgements

- Style guide content from HCP internal mini style guide, dated 04.14.26
  (preliminary, internal use only).
- Copy patterns synthesized from HCP top-spend ad copy, Apr 7 – May 6 2026.
- Higgsfield prompting skills authored by the Higgsfield team and adapted
  here for HCP-aligned use.

Maintained by Jackson Sherwood.
